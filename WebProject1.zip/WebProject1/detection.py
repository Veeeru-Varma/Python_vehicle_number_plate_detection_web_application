import cv2
import easyocr
import numpy as np
from datetime import datetime
from ultralytics import YOLO

# Initialize YOLOv8 model
model = YOLO('yolov8n.pt')  # Path to YOLOv8 model
model.overrides['verbose'] = False
# Initialize EasyOCR reader
reader = easyocr.Reader(['en'])  # For English plates
# Load Haar Cascade for license plate detection
plate_cascade = cv2.CascadeClassifier('Model/indian_license_plate.xml')

min_area = 500
Plt_no1 = "AN11AA1111"

def preprocess_plate_image(plate_roi):
    """Apply a series of image processing techniques to enhance the license plate image."""
    
    # Convert to grayscale
    gray = cv2.cvtColor(plate_roi, cv2.COLOR_BGR2GRAY)
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Apply adaptive thresholding to create a binary image
    thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY_INV, 11, 2)
    
    # Apply morphological operations to clean up the image
    kernel = np.ones((3, 3), np.uint8)
    morph = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    morph = cv2.morphologyEx(morph, cv2.MORPH_OPEN, kernel)

    return morph

def detect_and_read_plate(img, vehicle_box):
    global Plt_no1
    """Detect and read the license plate from the detected vehicle."""
    x1, y1, x2, y2 = map(int, vehicle_box)
    vehicle_roi = img[y1:y2, x1:x2]  # Crop vehicle region from the frame

    # Convert vehicle ROI to grayscale for license plate detection
    gray_vehicle = cv2.cvtColor(vehicle_roi, cv2.COLOR_BGR2GRAY)

    # Detect license plates within the vehicle region
    plates = plate_cascade.detectMultiScale(gray_vehicle, 1.1, 4)

    for (px, py, pw, ph) in plates:
        # Extract license plate region of interest (ROI)
        plate_roi = vehicle_roi[py:py+ph, px:px+pw]

        # Ensure the detected plate area is large enough
        if pw * ph > min_area:
            # Preprocess the plate ROI for better OCR
            processed_plate = preprocess_plate_image(plate_roi)

            # Optionally, visualize the processed image for debugging
            cv2.imshow("Processed Plate Image", processed_plate)
            cv2.waitKey(1)  # Small delay to visualize

            # Read the text from the plate using EasyOCR
            result = reader.readtext(processed_plate)
            if result:
                # Extract detected text (license plate number)
                plate_text = result[0][-2].replace(" ", "").upper()

                # Remove special characters
                special_chars = "!?'@#$%^&*¥()_+=-[]{}|;:'\",.<>?/`~"
                translator = str.maketrans('', '', special_chars)
                cleaned_NO = plate_text.translate(translator)

                # checking plate states code and number
                state_code = cleaned_NO[:2]
                third_four = cleaned_NO[2:4]
                last_four = cleaned_NO[-4:]
                alph2 = cleaned_NO[-6:-4]

                # Validate and save the license plate image with the number as the filename
                print(f"No:  {cleaned_NO}")
                if len(cleaned_NO) < 11 and len(cleaned_NO) > 8 and Plt_no1 != cleaned_NO:
                    Plt_no1 = cleaned_NO
                    
                    print(f"save_plate_image======:  {cleaned_NO}")
                    save_plate_image(plate_roi, cleaned_NO)
                    return cleaned_NO  # Return detected plate text to display on the frame

    return None  # No plate detected

# ============== old code===========
# def detect_and_read_plate(img, vehicle_box):
#     global Plt_no1
#     """Detect and read the license plate from the detected vehicle."""
#     x1, y1, x2, y2 = map(int, vehicle_box)
#     vehicle_roi = img[y1:y2, x1:x2]  # Crop vehicle region from the frame

#     # Convert vehicle ROI to grayscale for license plate detection
#     gray_vehicle = cv2.cvtColor(vehicle_roi, cv2.COLOR_BGR2GRAY)

#     # Detect license plates within the vehicle region
#     plates = plate_cascade.detectMultiScale(gray_vehicle, 1.1, 4)

#     for (px, py, pw, ph) in plates:
#         # Extract license plate region of interest (ROI)
#         plate_roi = vehicle_roi[py:py+ph, px:px+pw]

#         # Ensure the detected plate area is large enough
#         if pw * ph > min_area:
#             # Read the text from the plate using EasyOCR
#             Plateedged=cv2.Canny(plate_roi, 100, 200)
#             cv2.imshow("Plate Canny edge",Plateedged)
#             result = reader.readtext(Plateedged)
#             if result:
#                 # Extract detected text (license plate number)
#                 plate_text = result[0][-2].replace(" ", "").upper()

#                 # Remove special characters
#                 special_chars = "!?'@#$%^&*¥()_+=-[]{}|;:'\",.<>?/`~"
#                 translator = str.maketrans('', '', special_chars)
#                 cleaned_NO = plate_text.translate(translator)         

#                 # checking plate states code and number
#                 state_code = cleaned_NO[:2]
#                 third_four = cleaned_NO[2:4]
#                 last_four = cleaned_NO[-4:]
#                 # Extract the two characters before the last 4 digits
#                 alph2 = cleaned_NO[-6:-4]

#                 # print(f"out of condition:  {cleaned_NO}")
#                 # Validate and save the license plate image with the number as the filename
#                 print(f"No:  {cleaned_NO}")
#                 # if  len(cleaned_NO) < 11 and len(cleaned_NO) > 8 and state_code.isalpha() and alph2.isalpha()  and third_four.isdigit() and last_four.isdigit() and Plt_no1!=cleaned_NO:
#                 if  len(cleaned_NO) < 11 and len(cleaned_NO) > 8 and Plt_no1!=cleaned_NO:
#                     Plt_no1=cleaned_NO
                    
#                     print(f"save_plate_image======:  {cleaned_NO}")
#                     save_plate_image(plate_roi, cleaned_NO)
#                     return cleaned_NO  # Return detected plate text to display on the frame
#     return None  # No plate detected

def save_plate_image(plate_img, cleaned_NO):
    """Save the license plate image with current timestamp and detected number."""
    current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
    img_name = f"static/Plates/{current_datetime}_{cleaned_NO}.jpg"
    cv2.imwrite(img_name, plate_img)
    print(f"Saved plate: {img_name} :: {cleaned_NO}")

# Set desired display dimensions
display_width = 800  # Desired width
display_height = 500  # Desired height


def detect_vehicle_and_plate(frame):
    """Process each frame for vehicle and license plate detection."""
    display_width = 800
    display_height = 500

    img_resized = cv2.resize(frame, (display_width, display_height))
    results = model(img_resized)

    for result in results:
        boxes = result.boxes
        for box in boxes:
            cls_id = int(box.cls[0])
            label = model.names[cls_id]

            if label in ['car', 'bus', 'truck', 'bike']:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                area = (x2 - x1) * (y2 - y1)

                if area > min_area:
                    cv2.rectangle(img_resized, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(img_resized, f"{label}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
                    plate_text = detect_and_read_plate(img_resized, [x1, y1, x2, y2])
                    if plate_text:
                        cv2.putText(img_resized, f"Plate: {plate_text}", (x1, y1 - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
    return img_resized

# def detect_and_read_plate(img, vehicle_box):
#     # Existing license plate detection logic...
#     pass
