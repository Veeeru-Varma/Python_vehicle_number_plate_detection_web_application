from flask import Flask, render_template, Response, jsonify
import cv2
import os
import time
from detection import detect_vehicle_and_plate  # Import your detection logic

app = Flask(__name__)

camera_url = "rtsp://admin:123456@192.168.1.202:554/profile1"  # Change as needed

# Directory to store the license plate images
PLATE_IMAGES_DIR = 'static/Plates/'


def gen_frames(folder='CarImages'):
    for image_name in os.listdir(folder):
        image_path = os.path.join(folder, image_name)
        if image_name.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
            frame = cv2.imread(image_path)
            frame = detect_vehicle_and_plate(frame)
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()

            # Return a frame as a byte array for streaming
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            # time.sleep(2)



# def gen_frames():
#     """Capture video frames from the camera and run detection."""
#     cap = cv2.VideoCapture(camera_url)
#     # cap = cv2.VideoCapture(0)
#     while True:
#         success, frame = cap.read()
#         if not success:
#             break
#         else:
#             # Pass the frame to your detection logic
#             frame = detect_vehicle_and_plate(frame)
#             ret, buffer = cv2.imencode('.jpg', frame)
#             frame = buffer.tobytes()

#             # Return a frame as a byte array for streaming
#             yield (b'--frame\r\n'
#                    b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            

# @app.route('/')
# def index():
#     """Render the main page with saved plate images."""
#     # Get the list of saved plate images
#     plate_images = [img for img in os.listdir(PLATE_IMAGES_DIR) if img.endswith('.jpg')]
#     plate_images.sort(reverse=True)  # Sort images to show the latest first
#     return render_template('index.html', plate_images=plate_images)

def get_sorted_plate_images():
    """Retrieve and sort the saved plate images."""
    # Get the list of saved plate images
    plate_images = [img for img in os.listdir(PLATE_IMAGES_DIR) if img.endswith('.jpg')]
    plate_images.sort(reverse=True)  # Sort images to show the latest first
    return plate_images


@app.route('/get_plate_images')
def get_plate_images():
    """Return updated plate images as JSON."""
    plate_images = get_sorted_plate_images()  # Get updated images
    return jsonify(plate_images=plate_images)

@app.route('/video_feed')
def video_feed():
    """Route to provide video streaming."""
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/DetectPlates')
def render_detected_plates():
    """Render the main page with saved plate images."""
    plate_images = get_sorted_plate_images()  # Call the method to get sorted images
    return render_template('index.html', plate_images=plate_images)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)











# from flask import Flask, render_template, Response
# import cv2
# from detection import detect_vehicle_and_plate  # Import your detection logic

# app = Flask(__name__)

# camera_url = "rtsp://admin:123456@192.168.1.202:554/profile1"  # Change as needed

# def gen_frames():
#     """Capture video frames from the camera and run detection."""
#     # cap = cv2.VideoCapture(camera_url)
#     cap = cv2.VideoCapture(0)
#     while True:
#         success, frame = cap.read()
#         if not success:
#             break
#         else:
#             # Pass the frame to your detection logic
#             frame = detect_vehicle_and_plate(frame)
#             ret, buffer = cv2.imencode('.jpg', frame)
#             frame = buffer.tobytes()

#             # Return a frame as a byte array for streaming
#             yield (b'--frame\r\n'
#                    b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

# @app.route('/')
# def index():
#     """Render the main page."""
#     return render_template('index.html')

# @app.route('/video_feed')
# def video_feed():
#     """Route to provide video streaming."""
#     return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)
